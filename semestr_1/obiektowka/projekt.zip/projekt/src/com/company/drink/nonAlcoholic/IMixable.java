package com.company.drink.nonAlcoholic;

public interface IMixable {
    void mixWith(NonAlcoholicDrink nonAlcoholicDrink);
}

package com.company.drink.alcoholic;

public enum GinType {
    JUNIPER_FLAVORED,
    TRADITIONAL,
    DISTILLED,
    LONDON,
    FLAVORED
}
